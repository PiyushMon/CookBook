//
//  SearchVC.swift
//  Cookbook
//
//  Created by user216453 on 11/12/22.
//

import UIKit

class SearchVC: BaseViewController, UITextFieldDelegate {
    
    @IBOutlet weak var viewSerach: UIView!
    @IBOutlet weak var txtSerach: UITextField!
    @IBOutlet weak var tblMeals: UITableView!
    @IBOutlet weak var lblSearch: UILabel!
    
    var arrMeals = [MealsDetails]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        hideKeyboardWhenTappedAround()
        viewSerach.layer.cornerRadius = 10
        viewSerach.layer.borderColor = UIColor.gray.withAlphaComponent(0.3).cgColor
        viewSerach.layer.borderWidth = 0.8
        
        setupTbl()
        txtSerach.delegate = self
        lblSearch.text = "SEARCH".localized()
        txtSerach.placeholder = "SEARCH_MEAL_BY_NAME".localized()
        txtSerach.text = "Arrabiata"
        

    }
    
    func setupTbl() {
        tblMeals.delegate = self
        tblMeals.dataSource = self
        tblMeals.register(UINib(nibName: "IngredientCell", bundle: nil), forCellReuseIdentifier: "IngredientCell")
        tblMeals.reloadData()
    }
    
    func hideKeyboardWhenTappedAround() {
        let tapGesture = UITapGestureRecognizer(target: self,
                         action: #selector(hideKeyboard))
        tapGesture.cancelsTouchesInView = false
        view.addGestureRecognizer(tapGesture)
    }

    @objc func hideKeyboard() {
        view.endEditing(true)
    }
    
    @IBAction func onBtnSearch(_ sender: Any) {
        if let text = txtSerach.text, text.count > 0 {
            getMealsByName(name: txtSerach.text ?? "")
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txtSerach.resignFirstResponder()
        return true
    }
}

extension SearchVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        arrMeals.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "IngredientCell") as?  IngredientCell else { return .init() }
        cell.lblTitle.text = arrMeals[indexPath.row].strMeal
        cell.img.sd_setImage(with: URL(string: arrMeals[indexPath.row].strMealThumb ?? ""), placeholderImage: UIImage(named: "ic_placeholder"), options: .progressiveLoad, completed: nil)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MealsDetailsVC") as! MealsDetailsVC
        vc.mealDetails = arrMeals[indexPath.row]
        self.pushController(vc)
    }
    
    
    func getMealsByName(name: String) {
        APIMAnager.shared.getMealsByName(name: name) { arrMealsDetails in
            DispatchQueue.main.async {
                self.arrMeals.append(contentsOf: arrMealsDetails)
                self.tblMeals.reloadData()
            }
        } fail: { msg in
            self.showAlert(msg: msg)
        }
    }
}
