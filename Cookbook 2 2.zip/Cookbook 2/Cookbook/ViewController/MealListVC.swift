//
//  MealListVC.swift
//  Cookbook
//
//  Created by user216453 on 11/12/22.
//

import UIKit

class MealListVC: UIViewController {

    @IBOutlet weak var lblMealList: UILabel!
    @IBOutlet weak var tblMeals: UITableView!

    var arrMeals = [Meals]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTbl()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = true
        lblMealList.text = "MEAL_LIST".localized()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.tabBarController?.tabBar.isHidden = false
    }
    
    func setupTbl() {
        tblMeals.delegate = self
        tblMeals.dataSource = self
        tblMeals.register(UINib(nibName: "IngredientCell", bundle: nil), forCellReuseIdentifier: "IngredientCell")
        tblMeals.reloadData()
    }
    
    @IBAction func onBtnBack(_ sender: Any) {
        self.popVC()
    }
    
    
}

extension MealListVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        arrMeals.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "IngredientCell") as?  IngredientCell else { return .init() }
        cell.lblTitle.text = arrMeals[indexPath.row].strMeal
        cell.img.sd_setImage(with: URL(string: arrMeals[indexPath.row].strMealThumb ?? ""), placeholderImage: UIImage(named: "ic_placeholder"), options: .progressiveLoad, completed: nil)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        getFullMealDetailsById(id: arrMeals[indexPath.row].idMeal!)
    }
    
    
    func getFullMealDetailsById(id: String) {
        APIMAnager.shared.getFullMealDetailsById(id: id) { mealsDetails in
            DispatchQueue.main.async {
                let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MealsDetailsVC") as! MealsDetailsVC
                vc.mealDetails = mealsDetails
                self.pushController(vc)
            }
        } fail: { msg in
            self.showAlert(msg: msg)
        }
    }
}
