//
//  IngredientCell.swift
//  Cookbook
//
//  Created by user216453 on 11/12/22.
//

import UIKit

class IngredientCell: UITableViewCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        img.layer.cornerRadius = 10
    }

}
