//
//  AreaCell.swift
//  CarHome
//
//  Created by PC on 18/01/22.
//

import UIKit

class AreaCell: UICollectionViewCell {
    
    // MARK: - @IBOutlet
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var viewRadius: UIView!
    
    // MARK: - LifeCycle
    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
    }
    
    // MARK: - Functions
    /// Description:- Setup UI components.
    private func setupUI() {
       
        viewRadius.layer.cornerRadius = viewRadius.frame.height/2
        viewRadius.setBorder(1.0, UIColor.lightGray, 20)
    }
}


extension UIView {
    
    func setBorder( _ width : CGFloat ,_ borderColour : UIColor? = nil ,_ cornerRadius : CGFloat? = 0) {
        self.layer.borderWidth = width
        self.layer.masksToBounds = true
        self.layer.cornerRadius = cornerRadius ?? 0
        if borderColour != nil {
            self.layer.borderColor = borderColour!.cgColor
        }
        else {
            self.layer.borderColor = borderColour?.cgColor
        }
    }
    
}
