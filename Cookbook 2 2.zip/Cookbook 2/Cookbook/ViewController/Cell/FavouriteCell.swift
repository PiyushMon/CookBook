//
//  FavouriteCell.swift
//  Cookbook
//
//  Created by user216453 on 11/12/22.
//

import UIKit

class FavouriteCell: UITableViewCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblArea: UILabel!
    @IBOutlet weak var lblCategory: UILabel!
    @IBOutlet weak var switchRemove: UISwitch!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        img.layer.cornerRadius = 10
    }

    
}
