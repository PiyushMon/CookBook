//
//  MealCategoriesCell.swift
//  Cookbook
//
//  Created by user216453 on 11/12/22.
//

import UIKit

class MealCategoriesCell: UICollectionViewCell {
    
    @IBOutlet weak var viewRadias: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var imgMeal: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        viewRadias.layer.cornerRadius = 10
        self.addShadow(color: .black, opacity: 0.60, offset: CGSize.zero, radius: 1)
    }

}

extension UIView {
    
    public func addShadow(color: UIColor, opacity: Float, offset: CGSize, radius: CGFloat) {
        self.layer.shadowColor = color.cgColor
        self.layer.shadowOpacity = opacity
        self.layer.shadowOffset = offset
        self.layer.shadowRadius = radius
        self.layer.masksToBounds = false
    }
}
