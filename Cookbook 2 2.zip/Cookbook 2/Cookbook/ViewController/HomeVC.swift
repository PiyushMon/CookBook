//
//  HomeVC.swift
//  Cookbook
//
//  Created by user216453 on 11/12/22.
//

import UIKit
import SDWebImage

class HomeVC: BaseViewController {
    
    @IBOutlet weak var tblHeight: NSLayoutConstraint!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var clvArea: UICollectionView!
    @IBOutlet weak var clvMealCategories: UICollectionView!
    @IBOutlet weak var tblingredient: UITableView!
    @IBOutlet weak var actIndicater: UIActivityIndicatorView!
    
    
    @IBOutlet weak var lblHome: UILabel!
    @IBOutlet weak var lblAreaList: UILabel!
    @IBOutlet weak var lblCategory: UILabel!
    @IBOutlet weak var lblIngredientList: UILabel!
    
    
    var arrArea = [Meals]()
    var arrMealCategories = [Categories]()
    var arrAllIngredients = [Meals]()
    
    
    let HARIZONTAL_SPCE_IMAGE: CGFloat          = 12
    let VERTICAL_SPCE_IMAGE: CGFloat            = 16
    let COLUMN_IMAGE: CGFloat                   = 3
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupCollctionView()
        setupTbl()
        getAllMealCategories()
        getAllArea()
        getAllIngredients()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        localized()
    }
    
    func localized() {
        lblHome.text = "HOME".localized()
        lblAreaList.text = "AREA_LIST".localized()
        lblCategory.text = "CATEGORY".localized()
        lblIngredientList.text = "INGREDIENT_LIST".localized()
    }
    
    private func setupCollctionView() {
        clvArea.delegate = self
        clvArea.dataSource = self
        clvArea.register(UINib(nibName: "AreaCell", bundle: nil), forCellWithReuseIdentifier: "AreaCell")
        clvArea.reloadData()
        
        clvMealCategories.delegate = self
        clvMealCategories.dataSource = self
        clvMealCategories.register(UINib(nibName: "MealCategoriesCell", bundle: nil), forCellWithReuseIdentifier: "MealCategoriesCell")
        clvMealCategories.reloadData()
    }
    
    func setupTbl() {
        tblingredient.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
        tblingredient.delegate = self
        tblingredient.dataSource = self
        tblingredient.register(UINib(nibName: "IngredientCell", bundle: nil), forCellReuseIdentifier: "IngredientCell")
        tblingredient.reloadData()
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if let obj = object as? UITableView, keyPath == "contentSize", let newSize = change?[.newKey] as? CGSize {
            if obj == self.tblingredient {
                self.tblHeight.constant = newSize.height
            }
            self.scrollView.flashScrollIndicators()
            self.view.layoutIfNeeded()
        }
    }
}

extension HomeVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        arrAllIngredients.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "IngredientCell") as?  IngredientCell else { return .init() }
        cell.lblTitle.text = arrAllIngredients[indexPath.row].strIngredient
        let imgurl = "https://www.themealdb.com/images/ingredients/\(arrAllIngredients[indexPath.row].strIngredient!)-Small.png"
        cell.img.sd_setImage(with: URL(string: imgurl), placeholderImage: UIImage(named: "ic_placeholder"), options: .progressiveLoad, completed: nil)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        filterByIngredient(ingredientName: arrAllIngredients[indexPath.row].strIngredient ?? "")
    }
}

extension HomeVC: UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == clvArea {
            return arrArea.count
        } else {
            return arrMealCategories.count
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == clvArea {
            guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AreaCell", for: indexPath) as? AreaCell else {
                return UICollectionViewCell()
            }
            cell.lblTitle.text = arrArea[indexPath.row].strArea
            return cell
        } else {
            guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MealCategoriesCell", for: indexPath) as? MealCategoriesCell else {
                return UICollectionViewCell()
            }
            cell.lblTitle.text = arrMealCategories[indexPath.row].strCategory
//            cell.imgMeal.sd_imageIndicator = SDWebImageActivityIndicator.gray

            cell.imgMeal.sd_setImage(with: URL(string: arrMealCategories[indexPath.row].strCategoryThumb ?? ""), placeholderImage: UIImage(named: "ic_placeholder"), options: .progressiveLoad, completed: nil)
       
            return cell
        }

    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == self.clvArea {
            filterByArea(areaName: arrArea[indexPath.row].strArea ?? "")
        } else {
            filterByCategory(categoryName: arrMealCategories[indexPath.row].strCategory ?? "")
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if collectionView == self.clvArea {
            guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AreaCell", for: indexPath) as? AreaCell else {
                return CGSize()
            }
            cell.lblTitle.text = arrArea[indexPath.row].strArea ?? ""
            cell.setNeedsLayout()
            cell.layoutIfNeeded()
            let size: CGSize = cell.contentView.systemLayoutSizeFitting(UIView.layoutFittingCompressedSize)
            
            return CGSize(width: size.width, height: 40)
            
        } else {
            let width: CGFloat = (collectionView.frame.width - ((COLUMN_IMAGE - 1) * HARIZONTAL_SPCE_IMAGE)) / COLUMN_IMAGE
            return CGSize(width: width, height: 145)
        }
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat { return HARIZONTAL_SPCE_IMAGE }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat { return VERTICAL_SPCE_IMAGE }
}


extension HomeVC {
    
    func getAllMealCategories() {
        actIndicater.isHidden = false
        actIndicater.startAnimating()
        APIMAnager.shared.getAllMealCategories { arrMealCategories in
            print(arrMealCategories)
            self.arrMealCategories = arrMealCategories
            DispatchQueue.main.async {
                self.actIndicater.isHidden = true
                self.actIndicater.stopAnimating()
                self.clvMealCategories.reloadData()
            }
        } fail: { msg in
            self.actIndicater.isHidden = true
            self.actIndicater.stopAnimating()
            self.showAlert(msg: msg)
        }
    }
    
    func filterByArea(areaName: String) {
        actIndicater.isHidden = false
        actIndicater.startAnimating()
        APIMAnager.shared.filterByArea(areaName: areaName) { arrMeals in
            DispatchQueue.main.async {
                self.actIndicater.isHidden = true
                self.actIndicater.stopAnimating()
                let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MealListVC") as! MealListVC
                vc.arrMeals = arrMeals ?? []
                self.pushController(vc)
            }
        } fail: { msg in
            self.actIndicater.isHidden = true
            self.actIndicater.stopAnimating()
            self.showAlert(msg: msg)
        }
    }
    
    func filterByIngredient(ingredientName: String) {
        actIndicater.isHidden = false
        actIndicater.startAnimating()
        APIMAnager.shared.filterByIngredient(ingredientName: ingredientName) { arrMeals in
            DispatchQueue.main.async {
                self.actIndicater.isHidden = true
                self.actIndicater.stopAnimating()
                let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MealListVC") as! MealListVC
                vc.arrMeals = arrMeals ?? []
                self.pushController(vc)
            }
        } fail: { msg in
            self.actIndicater.isHidden = true
            self.actIndicater.stopAnimating()
            self.showAlert(msg: msg)
        }
    }
    
    func filterByCategory(categoryName: String) {
        actIndicater.isHidden = false
        actIndicater.startAnimating()
        APIMAnager.shared.filterByCategory(categoryName: categoryName) { arrMeals in
            DispatchQueue.main.async {
                self.actIndicater.isHidden = true
                self.actIndicater.stopAnimating()
                let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MealListVC") as! MealListVC
                vc.arrMeals = arrMeals ?? []
                self.pushController(vc)
            }
        } fail: { msg in
            self.actIndicater.isHidden = true
            self.actIndicater.stopAnimating()
            self.showAlert(msg: msg)
        }
    }
    
    
    func getAllArea() {
        actIndicater.isHidden = false
        actIndicater.startAnimating()
        APIMAnager.shared.getAllArea { arrArea in
            print(arrArea)
            self.arrArea = arrArea
            DispatchQueue.main.async {
                self.actIndicater.isHidden = true
                self.actIndicater.stopAnimating()
                self.clvArea.reloadData()
                self.clvMealCategories.reloadData()
            }
        } fail: { msg in
            self.actIndicater.isHidden = true
            self.actIndicater.stopAnimating()
            self.showAlert(msg: msg)
        }
        
    }
    
    func getAllIngredients() {
        actIndicater.isHidden = false
        actIndicater.startAnimating()
        APIMAnager.shared.getAllIngredients { arrAllIngredients in
            print(arrAllIngredients)
            self.arrAllIngredients = arrAllIngredients
            DispatchQueue.main.async {
                self.actIndicater.isHidden = true
                self.actIndicater.stopAnimating()
                self.tblingredient.reloadData()
            }
        } fail: { msg in
            self.actIndicater.isHidden = true
            self.actIndicater.stopAnimating()
            self.showAlert(msg: msg)
        }
        
    }
    
}
