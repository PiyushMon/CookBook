//
//  FavouriteVC.swift
//  Cookbook
//
//  Created by user216453 on 11/12/22.
//

import UIKit
import CoreData

class FavouriteVC: BaseViewController {

    @IBOutlet weak var tblFav: UITableView!
    @IBOutlet weak var lblFavourite: UILabel!
    
    @IBOutlet weak var lblCount: UILabel!
    @IBOutlet weak var lblRateUs: UILabel!
    
    var arrFav = [Favourite]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTbl()
    }
   
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchRecordsFromDB()
        lblFavourite.text = "FAVOURITE".localized()
        lblRateUs.text = "RATEUS".localized()
    }
    
    func setupTbl() {
        tblFav.delegate = self
        tblFav.dataSource = self
        tblFav.register(UINib(nibName: "FavouriteCell", bundle: nil), forCellReuseIdentifier: "FavouriteCell")
        tblFav.reloadData()
    }
    
    func fetchRecordsFromDB() {
        let path = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        print(path[0])
        
        do {
            guard let result = try PersistentStorage.shared.context.fetch(Favourite.fetchRequest()) as? [Favourite] else {return}
            arrFav.removeAll()
            arrFav.append(contentsOf: result)
            self.tblFav.reloadData()
            
        } catch let error {
            self.showAlert(msg: error.localizedDescription)
        }
    }
    
    func getRecord(byId id: UUID) -> Favourite? {
        let fetchRequest = NSFetchRequest<Favourite>(entityName: "Favourite")
        let fetchById = NSPredicate(format: "id==%@", id as CVarArg)
        fetchRequest.predicate = fetchById
        
        let result = try! PersistentStorage.shared.context.fetch(fetchRequest)
        guard result.count != 0 else {return nil}
        
        return result.first
    }
    
    func deleteRecord(byIdentifier id: UUID) -> Bool {
        let data = getRecord(byId: id)
        guard data != nil else {return false}
        
        PersistentStorage.shared.context.delete(data!)
        PersistentStorage.shared.saveContext()
        
        return true
    }
    
    @IBAction func sliderValueChanged(sender: UISlider) {
        let currentValue = Int(sender.value)
        lblCount.text = "\(currentValue)"
    }
}

extension FavouriteVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        arrFav.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "FavouriteCell") as?  FavouriteCell else { return .init() }
        cell.lblTitle.text = arrFav[indexPath.row].title
        cell.img.sd_setImage(with: URL(string: arrFav[indexPath.row].img ?? ""), placeholderImage: UIImage(named: "ic_placeholder"), options: .progressiveLoad, completed: nil)
        cell.lblArea.text = arrFav[indexPath.row].area ?? "" 
        cell.lblCategory.text = arrFav[indexPath.row].category ?? ""
        cell.switchRemove.tag = indexPath.row
        cell.switchRemove.isOn = true
        cell.switchRemove.addTarget(self, action: #selector(switchChanged), for: UIControl.Event.valueChanged)
        return cell
    }
    
    @objc func switchChanged(mySwitch: UISwitch) {
        if deleteRecord(byIdentifier: arrFav[mySwitch.tag].id ?? UUID()) {
            self.fetchRecordsFromDB()
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MealsDetailsVC") as! MealsDetailsVC
        vc.isFromFav = true
        vc.favModel = arrFav[indexPath.row]
        self.pushController(vc)
    }
    
}
