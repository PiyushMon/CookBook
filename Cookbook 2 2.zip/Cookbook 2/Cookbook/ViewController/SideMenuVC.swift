//
//  SideMenuVC.swift
//  Atlas
//
//  Created by user216453 on 05/12/22.
//

import UIKit


class SideMenuVC: BaseViewController {
    
    @IBOutlet weak var lblSettings: UILabel!
    @IBOutlet weak var lblApplang: UILabel!
    
    @IBOutlet weak var imgEng: UIImageView!
    @IBOutlet weak var imgHindi: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if UserDefaults.standard.integer(forKey: "LANG") == 1 {
            imgEng.isHidden = false
            imgHindi.isHidden = true
        } else {
            imgEng.isHidden = true
            imgHindi.isHidden = false
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
        localized()
    }
    
    static func fromStoryboard() -> SideMenuVC {
        guard let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SideMenuVC") as? SideMenuVC else { return Self() }
        return vc
    }
    
    func localized() {
        lblSettings.text = "SETTINGS".localized()
        lblApplang.text = "APP_LANGUAGE".localized()
    }
    
    @IBAction func onBtnEng(_ sender: Any) {
        UserDefaults.standard.set(1, forKey: "LANG")
        UserDefaults.standard.synchronize()
        
        imgEng.isHidden = false
        imgHindi.isHidden = true
        
        Utils.shared.getSceneDelegate()?.showRootVC()
    }
    
    @IBAction func onBtnHindi(_ sender: Any) {
        UserDefaults.standard.set(2, forKey: "LANG")
        UserDefaults.standard.synchronize()
        
        imgEng.isHidden = true
        imgHindi.isHidden = false
        Utils.shared.getSceneDelegate()?.showRootVC()
    }
}
