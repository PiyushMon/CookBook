//
//  MealsDetailsVC.swift
//  Cookbook
//
//  Created by user216453 on 11/12/22.
//

import UIKit
import SDWebImage
import CoreData

class MealsDetailsVC: UIViewController {
    @IBOutlet weak var btnAddToFav: UIButton!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblCategory: UILabel!
    @IBOutlet weak var lblArea: UILabel!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblInstructions: UILabel!
    @IBOutlet weak var lblIngredient: UILabel!
    
    var isFromFav = false
    var favModel: Favourite?
    var mealDetails: MealsDetails?
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.tabBarController?.tabBar.isHidden = false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadData()
        
        if isFromFav {
            btnAddToFav.setTitle( "REMOVE_FROM_FAVOURITE".localized(), for: .normal)
        } else {
            btnAddToFav.setTitle("ADD_TO_FAVOURITE".localized(), for: .normal)
        }
    }
    
    func loadData() {
        if isFromFav {
            
            guard let mealDetails = favModel else { return  }
            lblTitle.text = "\("MEAL".localized()): " + (mealDetails.title ?? "")
            lblCategory.text = "\("CATEGORY".localized()): " + (mealDetails.category ?? "")
            lblArea.text = "\("AREA".localized()): " + (mealDetails.area ?? "")
            lblInstructions.text = "\("INSTRUCTIONS".localized()): \n" + (mealDetails.instructions ?? "")
            lblIngredient.text = "\("INGREDIENT".localized()): " + (mealDetails.ingredient ?? "")
            img.sd_setImage(with: URL(string: mealDetails.img ?? ""), placeholderImage: UIImage(named: "ic_placeholder"), options: .progressiveLoad, completed: nil)
            
        } else {
            guard let mealDetails = mealDetails else { return  }
            lblTitle.text = "\("MEAL".localized()): " + (mealDetails.strMeal ?? "")
            lblCategory.text = "\("CATEGORY".localized()): " + (mealDetails.strCategory ?? "")
            lblArea.text = "\("AREA".localized()): " + (mealDetails.strArea ?? "")
            lblInstructions.text = "\("INSTRUCTIONS".localized()): \n" + (mealDetails.strInstructions ?? "")
            
            var str = ""
            str.append("\("INGREDIENT".localized()): " + (mealDetails.strIngredient1 ?? "") + ", ")
            str.append((mealDetails.strIngredient2 ?? "") + ", ")
            str.append((mealDetails.strIngredient3 ?? "") + ", ")
            str.append((mealDetails.strIngredient4 ?? "") + ", ")
            str.append((mealDetails.strIngredient5 ?? "") + ", ")
            str.append((mealDetails.strIngredient6 ?? "") + ", ")
            str.append((mealDetails.strIngredient7 ?? "") + ", ")
            str.append((mealDetails.strIngredient8 ?? "") + ", ")
            str.append((mealDetails.strIngredient9 ?? "") + ", ")
            str.append((mealDetails.strIngredient10 ?? "") + ", ")
            lblIngredient.text = str
            
            img.sd_setImage(with: URL(string: mealDetails.strMealThumb ?? ""), placeholderImage: UIImage(named: "ic_placeholder"), options: .progressiveLoad, completed: nil)
        }
    }
    @IBAction func onBtnBack(_ sender: Any) {
        self.popVC()
    }
    
    @IBAction func onBtnAddToFav(_ sender: Any) {
        if isFromFav {
            if deleteRecord(byIdentifier: favModel?.id! ?? UUID()) {
                self.showAlert(msg: "REMOVE_FROM_FAVOURITE_SUCCESSFULLY".localized()) {
                    self.popVC()
                }
            }
        } else {
            fetchRecordsFromDBCheck()
        }
        
    }
    
    func getRecord(byId id: UUID) -> Favourite? {
        let fetchRequest = NSFetchRequest<Favourite>(entityName: "Favourite")
        let fetchById = NSPredicate(format: "id==%@", id as CVarArg)
        fetchRequest.predicate = fetchById
        
        let result = try! PersistentStorage.shared.context.fetch(fetchRequest)
        guard result.count != 0 else {return nil}
        
        return result.first
    }
    
    func deleteRecord(byIdentifier id: UUID) -> Bool {
        let data = getRecord(byId: id)
        guard data != nil else {return false}
        
        PersistentStorage.shared.context.delete(data!)
        PersistentStorage.shared.saveContext()
        
        return true
    }
    
    func addIntoDB() {
        guard let mealDetails = mealDetails else { return  }
        let data = Favourite(context: PersistentStorage.shared.context)
        data.id = UUID()
        data.title = mealDetails.strMeal ?? ""
        data.category = mealDetails.strCategory ?? ""
        data.area = mealDetails.strArea ?? ""
        data.instructions = mealDetails.strInstructions ?? ""
        data.ingredient = lblIngredient.text ?? ""
        data.img = mealDetails.strMealThumb ?? ""
        PersistentStorage.shared.saveContext()
        
        self.showAlert(msg: "ADDED_SUCCESSFULLY".localized())
    }
    
    func fetchRecordsFromDBCheck() {
        let path = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        print(path[0])
        var arrCoreDbRecord = [Favourite]()
        do {
            guard let result = try PersistentStorage.shared.context.fetch(Favourite.fetchRequest()) as? [Favourite] else { return }
            arrCoreDbRecord.removeAll()
            arrCoreDbRecord.append(contentsOf: result)
            let titles = arrCoreDbRecord.map { $0.title }
            if titles.contains(mealDetails?.strMeal ?? "") {
                self.showAlert(msg: "THIS_RECIPE_ALREADY_ADDED_IN_TO_FAVORITE".localized())
            } else {
                addIntoDB()
            }
            
        } catch let error {
            self.showAlert(msg: error.localizedDescription)
        }
    }
}
