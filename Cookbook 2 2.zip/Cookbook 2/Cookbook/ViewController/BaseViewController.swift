//
//  BaseViewController.swift
//  Cookbook
//
//  Created by user216453 on 11/12/22.
//

import UIKit

class BaseViewController: UIViewController {
    
    var leftMenuNavigationController: SideMenuNavigationController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    //MARK:- Functions
    func setupMenu() {
        let sideMenuVC = SideMenuVC.fromStoryboard()
        leftMenuNavigationController = SideMenuNavigationController(rootViewController: sideMenuVC)
        SideMenuManager.default.leftMenuNavigationController = leftMenuNavigationController
        
        leftMenuNavigationController!.menuWidth =  275.0
        leftMenuNavigationController!.presentationStyle = .menuSlideIn
        leftMenuNavigationController!.presentationStyle.presentingEndAlpha = 0.50
        leftMenuNavigationController!.sideMenuManager.addPanGestureToPresent(toView: self.navigationController!.navigationBar)
        //side swipe Gestures
        leftMenuNavigationController!.sideMenuManager.addScreenEdgePanGesturesToPresent(toView: self.navigationController!.view)
        
    }
    
    
    @IBAction func onBtnMenu() {
        SideMenuManager.default.leftMenuNavigationController = leftMenuNavigationController
        
        if SideMenuManager.default.leftMenuNavigationController != nil {
            present(leftMenuNavigationController!, animated: true, completion: nil)
        } else {
            setupMenu()
            present(leftMenuNavigationController!, animated: true, completion: nil)
        }
    }
    
    @IBAction func onBtnCloseMenu() {
        SideMenuManager.default.leftMenuNavigationController?.dismissSideMenu()
    }
}
