//
//  ViewController.swift
//  Cookbook
//
//  Created by user216453 on 10/12/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }


}

