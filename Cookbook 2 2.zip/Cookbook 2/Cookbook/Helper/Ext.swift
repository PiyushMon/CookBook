//
//  Ext.swift
//  Cookbook
//
//  Created by user216453 on 11/12/22.
//

import Foundation
import UIKit

class Utils {
    static let shared = Utils()

    func getSceneDelegate() -> SceneDelegate? {
        guard let delegate = UIApplication.shared.connectedScenes.first else { return nil }
        return delegate.delegate as? SceneDelegate ?? nil
    }
    
}

extension UIViewController {
    func pushController(_ vc: UIViewController, animated:Bool = true) {
        self.navigationController?.pushViewController(vc, animated: animated)
    }
    
    func popVC(animated:Bool = true) {
        self.navigationController?.popViewController(animated: animated)
    }
    
    func presentController(_ vc: UIViewController, animated: Bool = true, completion: (() -> Void)? = nil) {
        self.present(vc, animated: animated, completion: completion)
    }
    
    
    func showAlert(msg: String) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: "ALERT".localized(), message: msg, preferredStyle: .alert)
            let title = "OK".localized()
            let btnOk = UIAlertAction(title: title, style: .default, handler: nil)
            alert.addAction(btnOk)
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func showAlert(msg: String, action: (() -> Void)? = nil) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: "ALERT".localized(), message: msg, preferredStyle: .alert)
            let title = "OK".localized()
            let btnOk = UIAlertAction(title: title, style: .default) { actions in
                action?()
            }
            alert.addAction(btnOk)
            self.present(alert, animated: true, completion: nil)
        }
    }
}

extension UIApplication {
    
    static func getTopViewController() -> UIViewController? {
        let keyWindow = UIApplication.shared.connectedScenes
            .filter({$0.activationState == .foregroundActive})
            .compactMap({$0 as? UIWindowScene})
            .first?.windows
            .filter({$0.isKeyWindow}).first
        var topController: UIViewController? = keyWindow?.rootViewController
        while topController?.presentedViewController != nil {
            topController = topController?.presentedViewController
        }
        return topController
    }
    
     class func rootViewController() -> UIViewController? {
         return UIApplication.shared.connectedScenes
                 .filter({$0.activationState == .foregroundActive})
                 .compactMap({$0 as? UIWindowScene})
                 .first?.windows
                 .filter({$0.isKeyWindow}).first?.rootViewController
     }
}

extension String {
    func localized() -> String {
        
        let languageCode = UserDefaults.standard.integer(forKey: "LANG")
        
        if languageCode == 1 {
            if let path = Bundle.main.path(forResource: "en", ofType: "lproj") {
                if let bundle = Bundle(path: path) {
                    return NSLocalizedString(self, tableName: "Localizable", bundle: bundle, value: "", comment: "")
                }
            }
        } else if languageCode == 2 {
            if let path = Bundle.main.path(forResource: "hi", ofType: "lproj") {
                if let bundle = Bundle(path: path) {
                    return NSLocalizedString(self, tableName: "Localizable", bundle: bundle, value: "", comment: "")
                }
            }
        }
        return NSLocalizedString(self, comment: "")
    }
}
