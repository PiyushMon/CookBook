//
//  APIMAnager.swift
//  Cookbook
//
//  Created by user216453 on 11/12/22.
//

import Foundation

class APIMAnager {
    
    static let shared = APIMAnager()
    
    
    func getAllArea(success: @escaping (([Meals])->()), fail: @escaping ((String)->())) {
        var req = URLRequest(url: URL(string: "https://www.themealdb.com/api/json/v1/1/list.php?a=list")!)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        
        URLSession.shared.dataTask(with: req) { Data, Response, error in
            if error != nil {
                fail(error?.localizedDescription ?? "Error")
                return
            }
            guard let data = Data else {
                fail(error?.localizedDescription ?? "Error")
                return
            }
            do {
                let json = try JSONDecoder().decode(BaseModel.self, from: data )
                print(json)
                success(json.meals ?? [])
            } catch let error {
                fail(error.localizedDescription)
                print("Error during JSON serialization: \(error.localizedDescription)")
            }
        }.resume()
    }
    
    func getAllMealCategories(success: @escaping (([Categories])->()), fail: @escaping ((String)->())) {
        var req = URLRequest(url: URL(string: "https://www.themealdb.com/api/json/v1/1/categories.php")!)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        
        URLSession.shared.dataTask(with: req) { Data, Response, error in
            if error != nil {
                fail(error?.localizedDescription ?? "Error")
                return
            }
            guard let data = Data else {
                fail(error?.localizedDescription ?? "Error")
                return
            }
            do {
                let json = try JSONDecoder().decode(BaseModel.self, from: data )
                print(json)
                success(json.categories ?? [])
            } catch let error {
                fail(error.localizedDescription)
                print("Error during JSON serialization: \(error.localizedDescription)")
            }
        }.resume()
    }
    
    
    func getAllIngredients(success: @escaping (([Meals])->()), fail: @escaping ((String)->())) {
        var req = URLRequest(url: URL(string: "https://www.themealdb.com/api/json/v1/1/list.php?i=list")!)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        
        URLSession.shared.dataTask(with: req) { Data, Response, error in
            if error != nil {
                fail(error?.localizedDescription ?? "Error")
                return
            }
            guard let data = Data else {
                fail(error?.localizedDescription ?? "Error")
                return
            }
            do {
                let json = try JSONDecoder().decode(BaseModel.self, from: data )
                print(json)
                success(json.meals ?? [])
            } catch let error {
                fail(error.localizedDescription)
                print("Error during JSON serialization: \(error.localizedDescription)")
            }
        }.resume()
    }
    
    
    func filterByArea(areaName: String,success: @escaping (([Meals]?)->()), fail: @escaping ((String)->())) {
        
        let urloldstr = "https://www.themealdb.com/api/json/v1/1/filter.php?a=\(areaName)"
        let urlString = urloldstr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        
        var req = URLRequest(url: URL(string: urlString)!)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        
        URLSession.shared.dataTask(with: req) { Data, Response, error in
            if error != nil {
                fail(error?.localizedDescription ?? "Error")
                return
            }
            guard let data = Data else {
                fail(error?.localizedDescription ?? "Error")
                return
            }
            do {
                let json = try JSONDecoder().decode(BaseModel.self, from: data )
                print(json)
                success(json.meals ?? [])
            } catch let error {
                fail(error.localizedDescription)
                print("Error during JSON serialization: \(error.localizedDescription)")
            }
        }.resume()
    }
    
    func filterByIngredient(ingredientName: String,success: @escaping (([Meals]?)->()), fail: @escaping ((String)->())) {
        let urloldstr = "https://www.themealdb.com/api/json/v1/1/filter.php?i=\(ingredientName)"
        let urlString = urloldstr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        
        guard let url = URL(string: urlString) else {
            fail("Invalid URL")
            return
        }
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        
        URLSession.shared.dataTask(with: req) { Data, Response, error in
            if error != nil {
                fail(error?.localizedDescription ?? "Error")
                return
            }
            guard let data = Data else {
                fail(error?.localizedDescription ?? "Error")
                return
            }
            do {
                let json = try JSONDecoder().decode(BaseModel.self, from: data )
                print(json)
                success(json.meals ?? [])
            } catch let error {
                fail(error.localizedDescription)
                print("Error during JSON serialization: \(error.localizedDescription)")
            }
        }.resume()
    }
    
    func filterByCategory(categoryName: String,success: @escaping (([Meals]?)->()), fail: @escaping ((String)->())) {
        var req = URLRequest(url: URL(string: "https://www.themealdb.com/api/json/v1/1/filter.php?c=\(categoryName)")!)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        
        URLSession.shared.dataTask(with: req) { Data, Response, error in
            if error != nil {
                fail(error?.localizedDescription ?? "Error")
                return
            }
            guard let data = Data else {
                fail(error?.localizedDescription ?? "Error")
                return
            }
            do {
                let json = try JSONDecoder().decode(BaseModel.self, from: data )
                print(json)
                success(json.meals ?? [])
            } catch let error {
                fail(error.localizedDescription)
                print("Error during JSON serialization: \(error.localizedDescription)")
            }
        }.resume()
    }

    
    func getFullMealDetailsById(id: String,success: @escaping ((MealsDetails?)->()), fail: @escaping ((String)->())) {
        var req = URLRequest(url: URL(string: "https://www.themealdb.com/api/json/v1/1/lookup.php?i=\(id)")!)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        
        URLSession.shared.dataTask(with: req) { Data, Response, error in
            if error != nil {
                fail(error?.localizedDescription ?? "Error")
                return
            }
            guard let data = Data else {
                fail(error?.localizedDescription ?? "Error")
                return
            }
            do {
                let json = try JSONDecoder().decode(MealsDetailsModel.self, from: data )
                print(json)
                success(json.meals?.first)
            } catch let error {
                fail(error.localizedDescription)
                print("Error during JSON serialization: \(error.localizedDescription)")
            }
        }.resume()
    }

    func getMealsByName(name: String,success: @escaping (([MealsDetails])->()), fail: @escaping ((String)->())) {
        var req = URLRequest(url: URL(string: "https://www.themealdb.com/api/json/v1/1/search.php?s=\(name)")!)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        
        URLSession.shared.dataTask(with: req) { Data, Response, error in
            if error != nil {
                fail(error?.localizedDescription ?? "Error")
                return
            }
            guard let data = Data else {
                fail(error?.localizedDescription ?? "Error")
                return
            }
            do {
                let json = try JSONDecoder().decode(MealsDetailsModel.self, from: data )
                print(json)
                success(json.meals ?? [])
            } catch let error {
                fail(error.localizedDescription)
                print("Error during JSON serialization: \(error.localizedDescription)")
            }
        }.resume()
    }
}
