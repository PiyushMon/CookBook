//
//  Favourite+CoreDataClass.swift
//  Cookbook
//
//  Created by user216453 on 11/12/22.
//
//

import Foundation
import CoreData

@objc(Favourite)
public class Favourite: NSManagedObject {

}
