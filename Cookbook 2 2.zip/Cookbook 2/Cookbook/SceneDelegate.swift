//
//  SceneDelegate.swift
//  Cookbook
//
//  Created by user216453 on 10/12/22.
//

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?
    private(set) static var shared: SceneDelegate?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = scene as? UIWindowScene else { return }
        
        let window = UIWindow(windowScene: windowScene)
        self.window = window
        guard let _ = (scene as? UIWindowScene) else { return }
        Self.shared = self
        
        showRootVC()
    }

    func showRootVC() {
        if !isKeyPresentInUserDefaults(key: "LANG") {
            UserDefaults.standard.set(1, forKey: "LANG")
            UserDefaults.standard.synchronize()
        }
        guard let tabBarVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "TabbarVC") as? TabbarVC else { return }
        let tabBarNavVC = UINavigationController(rootViewController: tabBarVC)
        tabBarNavVC.isNavigationBarHidden = true
        window?.rootViewController = tabBarNavVC
        window?.makeKeyAndVisible()
    }
    
    func isKeyPresentInUserDefaults(key: String) -> Bool {
        return UserDefaults.standard.object(forKey: key) != nil
    }
    
    func sceneDidDisconnect(_ scene: UIScene) {
     
    }

    func sceneDidBecomeActive(_ scene: UIScene) {
        
    }

    func sceneWillResignActive(_ scene: UIScene) {
      
    }

    func sceneWillEnterForeground(_ scene: UIScene) {
     
    }

    func sceneDidEnterBackground(_ scene: UIScene) {
        PersistentStorage.shared.saveContext()
    }


}

